# -*- coding: utf-8 -*-
# Copyright 2025 Odoo Community
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0)

# New enhanced controller with all endpoints
from . import main_new

# Legacy controller (deprecated)
# from . import main
