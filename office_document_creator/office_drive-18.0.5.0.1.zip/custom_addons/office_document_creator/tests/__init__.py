# -*- coding: utf-8 -*-
# Copyright 2025 Odoo Community
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0)

from . import test_office_document
from . import test_office_folder
from . import test_office_access
from . import test_office_version
from . import test_office_share
from . import test_office_controller
from . import test_office_integration
from . import test_office_performance
