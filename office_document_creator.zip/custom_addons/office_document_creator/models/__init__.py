# -*- coding: utf-8 -*-
from . import office_document
from . import office_folder
