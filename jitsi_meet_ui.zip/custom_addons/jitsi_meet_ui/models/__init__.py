# -*- coding: utf-8 -*-
from . import jitsi_meeting
from . import calendar_event
from . import res_config_settings
